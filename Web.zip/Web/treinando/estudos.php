<?php
	$array=array('Cristhian','22','Guarapuava');

	print count($array);
?>