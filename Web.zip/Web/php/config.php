<meta charset="utf-8">
<?php
$con = mysql_connect("localhost", "root", "pcom919491949") or die ("Não foi posvível conectar com o servidor");
mysql_select_db("pcom_talk", $con) or die ("O banco não foi localizado!");
?>