<?php
	session_start();
	require_once "config.php";


	echo "<script>alert('Para editar suas mensagens clique no icone que se parece com uma CANETA na coluna açoes! Obrigado!')</script>";
	echo "<meta http-equiv='refresh' content='0, url = ./Doc.php'>";
?>