<html>
<head>
	<title>teste de login</title>
</head>
<body>
	<table>
		<tr>
			<td> Login:  
			<input type="text" name="usuario">
			</td>
		</tr>
		<tr>
			<td> Senha:  
			<input type="password" name="senha">
			</td>
		</tr>
		<tr>
			<td>  
			<input type="submit" name="logar" value="Logar">
			</td>
		</tr>
	</table>
</body>
</html>